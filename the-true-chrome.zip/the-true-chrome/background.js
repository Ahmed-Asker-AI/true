importScripts("config.js");

// ---------- Real Google sign-in (OAuth 2.0 implicit flow) ----------
async function signIn() {
  const redirectUri = chrome.identity.getRedirectURL(); // https://<extension-id>.chromiumapp.org/
  const authUrl =
    "https://accounts.google.com/o/oauth2/v2/auth" +
    `?client_id=${encodeURIComponent(CONFIG.GOOGLE_CLIENT_ID)}` +
    `&response_type=token` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&scope=${encodeURIComponent("openid email profile")}` +
    `&prompt=select_account`;

  return new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true }, async (redirectedTo) => {
      if (chrome.runtime.lastError || !redirectedTo) {
        reject(chrome.runtime.lastError?.message || "Sign-in was cancelled.");
        return;
      }
      const hash = new URL(redirectedTo).hash.substring(1);
      const params = new URLSearchParams(hash);
      const accessToken = params.get("access_token");
      if (!accessToken) {
        reject("No access token returned.");
        return;
      }
      try {
        const res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        const profile = await res.json();
        const user = { name: profile.name, email: profile.email, picture: profile.picture };
        await chrome.storage.local.set({ theTrueUser: user });
        resolve(user);
      } catch (e) {
        reject("Could not fetch your Google profile.");
      }
    });
  });
}

async function signOut() {
  await chrome.storage.local.remove("theTrueUser");
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SIGN_IN") {
    signIn().then(user => sendResponse({ ok: true, user }))
            .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // keep the message channel open for the async response
  }
  if (msg.type === "SIGN_OUT") {
    signOut().then(() => sendResponse({ ok: true }));
    return true;
  }
});

// Badge showing how many flags content.js found on the active tab
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === "FLAG_COUNT" && sender.tab?.id) {
    chrome.action.setBadgeText({
      tabId: sender.tab.id,
      text: msg.count > 0 ? String(msg.count) : ""
    });
    chrome.action.setBadgeBackgroundColor({ tabId: sender.tab.id, color: "#b5483d" });
  }
});
