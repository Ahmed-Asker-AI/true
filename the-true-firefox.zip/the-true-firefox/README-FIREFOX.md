# تشغيل The True على فايرفوكس

النسخة دي معدّلة عشان تشتغل على فايرفوكس (الفرق عن نسخة كروم: طريقة الـ background script، وملف manifest.json مضاف له `browser_specific_settings`).

## 1. التحميل المؤقت (يشتغل فورًا، بيتشال لما تقفل فايرفوكس)

1. افتح `about:debugging#/runtime/this-firefox`
2. اضغط **Load Temporary Add-on…**
3. اختار ملف `manifest.json` من الفولدر ده
4. الأيقونة هتظهر في الشريط — جرّبها

## 2. تسجيل الدخول بجوجل (اختياري)

نفس خطوات نسخة الكروم في `config.js`، لكن الـ redirect URI هيكون مختلف لأن فايرفوكس بيحط ID مختلف لكل تحميل مؤقت:

1. حمّل الإضافة مؤقتًا زي فوق
2. في `about:debugging`، دوس على **Inspect** جنب The True، وشوف الـ Extension ID الظاهر
3. في Google Cloud Console → OAuth Client → Authorized redirect URIs، ضيف:
   `https://<الـ-ID-بتاعك>.extensions.allizom.org/`
4. حدّث `config.js` بالـ Client ID زي المعتاد

⚠️ ملحوظة: الـ Extension ID في فايرفوكس بيتغيّر كل مرة تعمل Load Temporary Add-on من جديد (إلا لو ثبّت `id` ثابت — وده موجود أصلاً هنا في `browser_specific_settings.gecko.id`: `the-true@extension.local`). يعني الـ redirect URI المفروض يفضل ثابت طول ما بتستخدم نفس ملف manifest.json ده.

## 3. عشان تفضل الإضافة موجودة دايمًا (مش مؤقتة)

فايرفوكس بيتطلب توقيع رسمي للإضافات الدائمة:

- ارفع الإضافة على https://addons.mozilla.org كـ **Unlisted** (مش لازم تنشرها للعامة) وحمّل النسخة الموقّعة اللي هتنزلها لك موزيلا.
- أو استخدم Firefox Developer Edition / Nightly، وفي `about:config` غيّر `xpinstall.signatures.required` لـ `false` — الطريقة دي للتطوير بس.
