# The True — Chrome Extension

A real, working Chrome extension:
- Scans the page you're on for suspicious/false-sounding text patterns and marks it live.
- Real Google sign-in (no mock).
- Schedule (Always / Custom hours / Off), per-site toggles, permission toggles, and a password lock — all actually stored and enforced.

## 1. Load the extension (works immediately, before Google login)

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select this folder.
4. The True's icon appears in your toolbar. Click it — the popup opens.

At this point everything works **except** "Continue with Google" — that needs your own Client ID (step 2).

## 2. Turn on real Google sign-in

1. Go to https://console.cloud.google.com and create a new project (e.g. "The True").
2. Go to **APIs & Services → OAuth consent screen** → choose **External** → fill in the app name and your email → save.
3. Go to **APIs & Services → Credentials** → **Create Credentials → OAuth client ID** → choose **Web application**.
4. Back in `chrome://extensions`, find The True's card and copy its **ID** (a long string under the name).
5. In the OAuth client you just created, add this to **Authorized redirect URIs**:
   `https://<YOUR-EXTENSION-ID>.chromiumapp.org/`
6. Copy the **Client ID** Google gives you (ends in `.apps.googleusercontent.com`).
7. Open `config.js` in this folder and paste it in:
   ```js
   const CONFIG = {
     GOOGLE_CLIENT_ID: "your-id-here.apps.googleusercontent.com"
   };
   ```
8. Back in `chrome://extensions`, click the reload icon on The True's card.
9. Open the popup and click **Continue with Google** — a real Google sign-in window opens.

## What's real vs. what's a placeholder

- **Real:** the content scanner (runs on every page you visit and flags text matching common misinformation patterns), Google sign-in, all settings (schedule, sites, permissions, lock) — these are read and enforced by `content.js` on every page load.
- **Placeholder:** the "true/false" detection is a simple keyword/pattern heuristic, not a trained fact-checking model. Swapping it for a real AI check would mean sending page text to a server you control (a browser extension can't safely hold a secret AI API key on its own).
