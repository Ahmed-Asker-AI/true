// ---------------------------------------------------------
// Paste the Google OAuth Client ID you created in
// Google Cloud Console here (type: "Web application").
// See README.md for the exact steps.
// ---------------------------------------------------------
const CONFIG = {
  GOOGLE_CLIENT_ID: "PASTE_YOUR_CLIENT_ID_HERE.apps.googleusercontent.com"
};
