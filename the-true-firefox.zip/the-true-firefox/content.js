(() => {
  const DEFAULT_SETTINGS = {
    enabled: true,
    locked: false,
    mode: "always", // "always" | "custom" | "off"
    customFrom: "09:00",
    customTo: "22:00",
    customDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    sites: {
      "instagram.com": true,
      "x.com": true,
      "twitter.com": true,
      "tiktok.com": true,
      "facebook.com": false,
      "threads.net": false
    },
    perms: {
      feed: true,
      marks: true,
      alerts: true,
      correction: true
    }
  };

  const SUSPICIOUS_PATTERNS = [
    /doctors?\s+(hate|don't want you)/i,
    /one weird trick/i,
    /share\s+(this\s+)?before\s+(it'?s\s+)?deleted/i,
    /they\s+don'?t\s+want\s+you\s+to\s+know/i,
    /100%\s*(guaranteed|proven|cure)/i,
    /cures?\s+(cancer|diabetes)\s+(instantly|overnight)/i,
    /breaking:?\s*.*(shocking|secret)/i,
    /you\s+won'?t\s+believe\s+what/i,
    /banned\s+by\s+the\s+government/i
  ];

  let scanned = new WeakSet();
  let flagCount = 0;

  function currentHost() {
    return location.hostname.replace(/^www\./, "");
  }

  function isSiteAllowed(settings) {
    const host = currentHost();
    const matches = Object.keys(settings.sites).filter(s => host.includes(s));
    if (matches.length === 0) return true; // unlisted sites: scan by default
    return matches.some(s => settings.sites[s]);
  }

  function isWithinSchedule(settings) {
    if (settings.mode === "off") return false;
    if (settings.mode === "always") return true;
    const now = new Date();
    const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const today = dayNames[now.getDay()];
    if (!settings.customDays.includes(today)) return false;
    const [fh, fm] = settings.customFrom.split(":").map(Number);
    const [th, tm] = settings.customTo.split(":").map(Number);
    const mins = now.getHours() * 60 + now.getMinutes();
    return mins >= fh * 60 + fm && mins <= th * 60 + tm;
  }

  function scoreText(text) {
    let hits = 0;
    for (const p of SUSPICIOUS_PATTERNS) if (p.test(text)) hits++;
    const shoutyWords = (text.match(/\b[A-Z]{4,}\b/g) || []).length;
    if (shoutyWords > 1) hits++;
    if (/!!!+/.test(text)) hits++;
    return hits;
  }

  function makeBadge(kind) {
    const badge = document.createElement("span");
    badge.className = "the-true-badge the-true-" + kind;
    badge.textContent = kind === "flag" ? "⚠ unverified — The True" : "✓ checked — The True";
    return badge;
  }

  function scanNode(node, settings) {
    if (scanned.has(node)) return;
    const text = (node.innerText || "").trim();
    if (text.length < 30 || text.length > 500) return;
    if (node.closest("script, style, nav, header, footer, .the-true-badge")) return;
    scanned.add(node);

    const hits = scoreText(text);
    if (hits > 0) {
      flagCount++;
      if (settings.perms.marks) {
        node.style.outline = "1px solid rgba(181,72,61,0.5)";
        node.appendChild(makeBadge("flag"));
      }
      if (settings.perms.alerts) {
        console.info("[The True] Flagged content:", text.slice(0, 80) + "…");
      }
    }
  }

  function scanPage(settings) {
    if (!settings.perms.feed) return;
    const candidates = document.querySelectorAll("p, span, article, div[role='article']");
    candidates.forEach(el => scanNode(el, settings));
    chrome.runtime.sendMessage({ type: "FLAG_COUNT", count: flagCount });
  }

  function shouldRun(settings) {
    return settings.enabled && !settings.locked && isSiteAllowed(settings) && isWithinSchedule(settings);
  }

  chrome.storage.local.get({ theTrueSettings: DEFAULT_SETTINGS }, ({ theTrueSettings }) => {
    const settings = { ...DEFAULT_SETTINGS, ...theTrueSettings };
    if (!shouldRun(settings)) return;

    scanPage(settings);

    const observer = new MutationObserver(() => {
      clearTimeout(window.__theTrueDebounce);
      window.__theTrueDebounce = setTimeout(() => scanPage(settings), 600);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
})();
