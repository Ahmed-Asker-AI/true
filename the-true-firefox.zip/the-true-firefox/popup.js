const DEFAULT_SETTINGS = {
  enabled: true,
  locked: false,
  lockPassword: null,
  mode: "always",
  customFrom: "09:00",
  customTo: "22:00",
  customDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
  sites: {
    "instagram.com": true,
    "x.com": true,
    "tiktok.com": true,
    "facebook.com": false,
    "whatsapp.com": false,
    "threads.net": false
  },
  perms: {
    feed: true,
    marks: true,
    alerts: true,
    correction: true,
    background: true,
    links: false
  }
};

let settings = structuredClone(DEFAULT_SETTINGS);

async function loadState() {
  const { theTrueUser } = await chrome.storage.local.get("theTrueUser");
  const { theTrueSettings } = await chrome.storage.local.get("theTrueSettings");
  settings = { ...DEFAULT_SETTINGS, ...(theTrueSettings || {}) };

  if (theTrueUser) {
    document.getElementById("view-login").classList.add("hidden");
    document.getElementById("view-app").classList.remove("hidden");
    document.getElementById("userName").textContent = theTrueUser.name || theTrueUser.email;
    document.getElementById("userPic").src = theTrueUser.picture || "";
    renderSettings();
    await updateFlagCount();
  } else {
    document.getElementById("view-login").classList.remove("hidden");
    document.getElementById("view-app").classList.add("hidden");
  }
}

async function updateFlagCount() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  try {
    const host = new URL(tab.url).hostname.replace(/^www\./, "");
    document.getElementById("siteState").textContent = host.split(".")[0];
  } catch (e) { /* chrome:// pages etc */ }
}

// ---------- Google sign-in ----------
document.getElementById("googleBtn").addEventListener("click", () => {
  const btn = document.getElementById("googleBtn");
  const err = document.getElementById("loginError");
  err.textContent = "";
  btn.disabled = true;
  chrome.runtime.sendMessage({ type: "SIGN_IN" }, (res) => {
    btn.disabled = false;
    if (res?.ok) {
      loadState();
    } else {
      err.textContent = res?.error || "Sign-in failed. Check config.js has a valid Client ID.";
    }
  });
});

document.getElementById("signOutBtn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "SIGN_OUT" }, () => loadState());
});

// ---------- Tabs ----------
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("panel-" + tab.dataset.panel).classList.add("active");
  });
});

// ---------- Render settings into the UI ----------
function renderSettings() {
  updatePresence();

  document.getElementById("masterSwitch").classList.toggle("on", settings.enabled);

  document.querySelectorAll(".mode-opt").forEach(o => o.classList.toggle("selected", o.dataset.mode === settings.mode));
  document.getElementById("customBox").classList.toggle("show", settings.mode === "custom");
  document.getElementById("timeFrom").value = settings.customFrom;
  document.getElementById("timeTo").value = settings.customTo;

  const daysRow = document.getElementById("daysRow");
  daysRow.innerHTML = "";
  ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].forEach(d => {
    const chip = document.createElement("div");
    chip.className = "day-chip" + (settings.customDays.includes(d) ? " on" : "");
    chip.textContent = d;
    chip.dataset.day = d;
    chip.addEventListener("click", () => {
      const i = settings.customDays.indexOf(d);
      if (i >= 0) settings.customDays.splice(i, 1); else settings.customDays.push(d);
      chip.classList.toggle("on");
    });
    daysRow.appendChild(chip);
  });

  const sitesList = document.getElementById("sitesList");
  sitesList.innerHTML = "";
  Object.entries(settings.sites).forEach(([site, on]) => {
    const row = document.createElement("div");
    row.className = "site-row";
    row.innerHTML = `<span class="name">${site}</span>`;
    const sw = document.createElement("div");
    sw.className = "switch" + (on ? " on" : "");
    sw.addEventListener("click", () => { settings.sites[site] = !settings.sites[site]; sw.classList.toggle("on"); });
    row.appendChild(sw);
    sitesList.appendChild(row);
  });

  const permsMeta = {
    feed: ["Read feed content", "Needed to check posts as they load."],
    marks: ["Show marks on screen", "Displays verified / unverified tags."],
    alerts: ["Send alerts", "Notifies you when something is flagged."],
    correction: ["Send the correct information", "Shows what's actually true, not just a warning."],
    background: ["Run in background", "Keeps checking while you use other tabs."],
    links: ["Check shared links", "Scans links before you open them."]
  };
  const permsList = document.getElementById("permsList");
  permsList.innerHTML = "";
  Object.entries(settings.perms).forEach(([key, on]) => {
    const [name, desc] = permsMeta[key] || [key, ""];
    const row = document.createElement("div");
    row.className = "perm-row";
    row.innerHTML = `<div><div class="name">${name}</div><div class="desc">${desc}</div></div>`;
    const sw = document.createElement("div");
    sw.className = "switch" + (on ? " on" : "");
    sw.addEventListener("click", () => { settings.perms[key] = !settings.perms[key]; sw.classList.toggle("on"); });
    row.appendChild(sw);
    permsList.appendChild(row);
  });
}

function updatePresence() {
  const dot = document.getElementById("topDot");
  const status = document.getElementById("topStatus");
  if (settings.locked) { dot.classList.add("off"); status.textContent = "locked"; }
  else if (!settings.enabled || settings.mode === "off") { dot.classList.add("off"); status.textContent = "off"; }
  else { dot.classList.remove("off"); status.textContent = settings.mode === "custom" ? "custom hours" : "watching"; }
}

document.getElementById("masterSwitch").addEventListener("click", (e) => {
  settings.enabled = !settings.enabled;
  e.currentTarget.classList.toggle("on");
  updatePresence();
});

document.querySelectorAll(".mode-opt").forEach(opt => {
  opt.addEventListener("click", () => {
    settings.mode = opt.dataset.mode;
    document.querySelectorAll(".mode-opt").forEach(o => o.classList.remove("selected"));
    opt.classList.add("selected");
    document.getElementById("customBox").classList.toggle("show", settings.mode === "custom");
    updatePresence();
  });
});

document.getElementById("lockBtn").addEventListener("click", () => {
  const pass = document.getElementById("lockPass").value;
  if (!pass) return;
  settings.locked = true;
  settings.lockPassword = pass;
  updatePresence();
  saveSettings(true);
});

document.getElementById("saveBtn").addEventListener("click", () => {
  settings.customFrom = document.getElementById("timeFrom").value || settings.customFrom;
  settings.customTo = document.getElementById("timeTo").value || settings.customTo;
  saveSettings();
});

function saveSettings(silent) {
  chrome.storage.local.set({ theTrueSettings: settings }, () => {
    if (!silent) {
      const note = document.getElementById("savedNote");
      note.classList.add("show");
      setTimeout(() => note.classList.remove("show"), 1500);
    }
  });
}

loadState();
